from pyamigamods.player import playmod

#playmod('./mods/CUST.Paranoimia-1.cust')
#playmod('./mods/hybris.fp')
#playmod('./mods/STK.bowlstheme')


#libxmp
#playmod('./mods/silly venture.mgt')

#libopenmpt
#playmod('./mods/starport bbs introtune.s3m')

#failure
playmod('./mods/burgertime mix.xm')

#playmod('./mods/mod.ORIENTALEV4.CHIP',2)
